### Dolibarr version 17 support.  
Change module identifier and permissions.  
Xlsx export added in note menu
